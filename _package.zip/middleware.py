from prototype import DalioBot
from flask import Flask, jsonify, request
from flask_restful import Resource, Api
from flask_cors import CORS
import requests

app = Flask(__name__)
api = Api(app)
CORS(app)


class status (Resource):
    def get(self):
        try:
            return {'data': 'Api is Running'}
        except:
            return {'data': 'An Error Occurred during fetching Api'}


class StateLessBot(Resource):
    def __init__(self):
        self.bot = DalioBot()

    def post(self):
        json_data = request.get_json(force=True)
        text = json_data['input']
        response = self.bot.respond(text)
        self.bot.chat_history = []
        return response


api.add_resource(status, '/')
api.add_resource(StateLessBot, '/chat')

if __name__ == '__main__':
    app.run()
